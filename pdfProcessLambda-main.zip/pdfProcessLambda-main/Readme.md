### Lambda Function for uploading nd processing a pdf.

## Requirements:
aws-SAM CLI, version 1.37.0
docker
python 3.8

## build:
1. git clone the directory 
2. install all requirements
3. call `sam build` in terminal in cloned directory

## deploy:
1. zip the `.aws-sam/build/LambdaFunction` in cloned repo
2. upload zip file to lambda function with correct handler and python version (use template.yaml as reference)
