import json
import base64
import email

from pdf_handler import processPDF


def processRespose(statusCode, body=""):
    return {
        "statusCode": statusCode,
        "headers": {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        },
        "body": json.dumps({
            "Message": body
        })
    }


def lambda_handler(event, context):

    # decoding form-data into bytes
    post_data = base64.b64decode(event["body"])

    # fetching content-type
    try:
        content_type = event["headers"]["Content-Type"]
    except Exception as e:
        content_type = event["headers"]["content-type"]
    # concate Content-Type: with content_type from event
    ct = "Content-Type: " + content_type + "\n"

    # parsing message from bytes
    msg = email.message_from_bytes(ct.encode() + post_data)

    # checking if the message is multipart
    print("Multipart check : ", msg.is_multipart())

    # if message is multipart
    if msg.is_multipart():
        multipart_content = {}
        # retrieving form-data
        for part in msg.get_payload():
            multipart_content[
                part.get_param("name", header="content-disposition")] = part.get_payload(decode=True)

        # filename from form-data
        file_name = multipart_content["filename"].decode("utf-8")
        pdf_data = multipart_content["file"]

        # process the pdf
        response = processPDF(file_name, pdf_data)
        # on upload success
        return processRespose(200, "Upload Successfull.")
    else:
        # on upload failure
        return processRespose(500, "Upload failed!")
