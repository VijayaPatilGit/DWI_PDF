# STEP 1
# import libraries
import os
import json
import boto3
import string
import random
import pymongo
import fitz
from pymongo import mongo_client


# for ^ use "pip install PyMuPDF"


s3 = boto3.client("s3")
bucket_name = "dwdocstore"

location = s3.get_bucket_location(Bucket=bucket_name)['LocationConstraint']

subfolder = ""
mongo_client = "mongodb+srv://NewDWIuser:NewDWIuser@DWI-Cluster.xlu3a.mongodb.net/DWI_DB?retryWrites=true&w=majority"

# config
dimlimit = 0  # 100  # each image side must be greater than this
# 0.05  # image : image size ratio must be larger than this (5%)
relsize = 0
abssize = 0  # 2048  # absolute image size limit 2 KB: ignore if smaller
page_title_max = 33
page_footer_min = 500


def get_database():
    client = pymongo.MongoClient(mongo_client)
    # Create the database for our example (we will use the same database throughout the tutorial
    return client['DWI_DB']


def processPDF(filename, pdf_data):
    # to create random string for pdfId
    Num_of_char = 10
    pdfId = ''.join(random.choices(
        string.ascii_uppercase + string.digits, k=Num_of_char))

    json_data = {"pdfName": filename, "pdfId": pdfId, "pdfPages": []}

    # open the file
    pdf_file = fitz.open(stream=pdf_data, filetype="pdf")

    s3.put_object(
        Bucket=bucket_name, Key=filename, Body=pdf_data
    )

    # iterate over PDF pages
    for page_index in range(len(pdf_file)):
        # get the page itself
        data = {}
        data["pageNumber"] = str(str(page_index + 1))
        page = pdf_file[page_index]

        page_text = page.get_text("text")  # or text, blocks, json, html
        page_text = " ".join(page_text.split())

        page_json = json.loads(page.get_text("json"))
        page_json_text = []
        page_title = ""
        page_footer = ""
        for blk in page_json["blocks"]:
            if blk["type"] == 0:
                for line in blk["lines"]:
                    for span in line["spans"]:
                        page_json_text.append(
                            {"bbox": span["bbox"], "text": span["text"]})
                        if (span["bbox"][1] <= page_title_max):
                            page_title = span["text"]
                        elif (span["bbox"][1] > page_footer_min):
                            page_footer = span["text"]
            data["pageTitle"] = page_title
            data["pageDescription"] = page_text.strip(
                page_title).strip(page_footer)
            data["pageDescriptionJson"] = page_json_text

        folderLocation = os.path.join(
            os.path.splitext(filename)[0], str(page_index+1))

        image_list = page.get_images()
        image_urls = []
        # printing number of images found in this page
        for _, img in enumerate(image_list, start=1):
            # get the XREF of the image
            xref = img[0]
            # extract the image bytes
            base_image = pdf_file.extract_image(xref)
            img = base_image["image"]
            width = base_image["width"]
            height = base_image["height"]
            n = base_image["colorspace"]

            # skip if image size is smaller than config
            if len(img) <= abssize:
                continue
            if len(img) / (width * height * n) <= relsize:
                continue
            if min(width, height) <= dimlimit:
                continue

            imgext = base_image["ext"]
            imgLocation = os.path.join(
                folderLocation, "img%05i.%s" % (xref, imgext))
            s3.put_object(
                Bucket=bucket_name, Key=imgLocation, Body=img
            )

            url = "https://%s.s3.%s.amazonaws.com/%s" % (
                bucket_name, location, imgLocation)
            image_urls.append(url)
        data["pageImages"] = image_urls

        json_data["pdfPages"].append(data)

    # Get the database
    dbname = get_database()
    collection_name = dbname["user_1_items"]
    collection_name.insert_many([json_data])
    return json_data
